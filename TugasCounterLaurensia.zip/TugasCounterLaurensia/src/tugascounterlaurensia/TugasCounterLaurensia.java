/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugascounterlaurensia;

import java.awt.*;
/**
 *
 * @author Laurensia Divina Dewi Fortuna - 21120117120010
 */
public class TugasCounterLaurensia extends Panel {
    private long count=0;
    private Label label;
    private long maxValue=20;
    public void setMaxValue(long max) {
        maxValue = max;
    }
    public long getMaxValue() {
        return maxValue;
    }
    public TugasCounterLaurensia() {
        setBackground(Color.blue);
        setForeground(Color.white);
        label = new Label(""+count);
        add(label);
    }
    public void increment () {
        if (count < maxValue) {
            count++;
            label.setText(count+" ");
        }
        else label.setText("!!");
    }
}
